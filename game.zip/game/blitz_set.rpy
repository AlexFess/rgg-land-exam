init:
    python:
        import random
        from yaml import load, Loader
        from datetime import datetime
        from datalib import Var


        blitz = Var(count=0, correct=0, max_count = 10, max_cat = 1, max_per_cat = 1, answered = {})
        blitz.current_question = {}
        start_time = datetime.now()

        blitz.images = [
            "map_fresh_2026_p1",
            "map_fresh_2026_p2",
        ]
        blitz.start_image = blitz.images[0]
#         blitz.current_image_id = -1
#         blitz.current_image = blitz.start_image
        blitz.end_image = blitz.images[-1]
#         random.shuffle(blitz.images)

        registry = load(renpy.file('blitz_questions.yml'), Loader=Loader)
        blitz.cat_number = len(registry)
        blitz.max_number = sum([len(r['category_questions']) for r in registry])

        blitz.names = ['', 'Быстром', 'Полном', 'Душном']

        def next_blitz():
            global blitz
            n_cat = random.randint(0, len(registry)-1)
            n = random.randint(0, len(registry[n_cat]['category_questions']) - 1)
            while n in blitz.answered.get(n_cat, []) or len(blitz.answered.get(n_cat, [])) >= blitz.max_per_cat:
                n_cat = random.randint(0, len(registry)-1)
                n = random.randint(0, len(registry[n_cat]['category_questions']) - 1)
            blitz.answered[n_cat] = blitz.answered.get(n_cat, []) + [n]
            blitz.current_question = registry[n_cat]['category_questions'][n]
#             renpy.hide(blitz.current_image)
#             blitz.current_image_id += 1
#             if blitz.current_image_id >= len(blitz.images):
#                 random.shuffle(blitz.images)
#                 blitz.current_image_id = 0
#             blitz.current_image = blitz.images[blitz.current_image_id]
#             renpy.show(blitz.current_image)
            renpy.jump("blitz_text")

        def exit_blitz():
            global challenger
            if challenger:
                challenger = None
#             if renpy.emscripten:
#                 import emscripten
#                 emscripten.run_script("window.location.search = ''")

label blitz_start:
    scene
    show map_fresh_2026_p1 at topleft
#     python:
#         global blitz, battle_arch, battle_type
#         blitz.count = 0
#         blitz.correct = 0
#         blitz.answered = {}
#         battle_arch = 1
#         if battle_type == 1:
#             blitz.max_count = 10
#         if battle_type == 2:
#             blitz.max_count = blitz.cat_number
#         if battle_type == 3:
#             blitz.max_count = blitz.max_number
#             blitz.max_per_cat = 999

    if challenger:
        jump blitz_prep_finish
    else:
        jump blitz_type_choice


label blitz_prep_finish:
    python:
        global blitz, battle_arch, battle_type
        blitz.count = 0
        blitz.correct = 0
        blitz.answered = {}
        battle_arch = 1
        blitz.max_per_cat = 1
        if battle_type == 1:
            blitz.max_count = 10
        if battle_type == 2:
            blitz.max_count = blitz.cat_number
        if battle_type == 3:
            blitz.max_count = blitz.max_number
            blitz.max_per_cat = 999
    nuke "[blitz.max_count] случайных вопросов из [blitz.max_number]. Погнали!"
    python:
        global start_time
        start_time = datetime.now()
    jump blitz_next


label blitz_type_choice:
    menu:
        nuke "Какой вариант теста будем тащить, [persistent.player_name]?"
        "Быстрый (10 вопросов)":
#             $ blitz.max_count = 10
#             $ blitz.max_per_cat = 1
            $ battle_type = 1
        "Полный ([blitz.cat_number] вопросов)":
#             $ blitz.max_count = blitz.cat_number
#             $ blitz.max_per_cat = 1
            $ battle_type = 2
        "Душный ([blitz.max_number] вопроса)":
#             $ blitz.max_count = blitz.max_number
#             $ blitz.max_per_cat = 999
            $ battle_type = 3
        "Я не [persistent.player_name]!":
            call screen input_name()
            jump blitz_type_choice
    jump blitz_prep_finish

label blitz_battle_confirm:
    jump blitz_prep_finish

label blitz_next:
    $ next_blitz()

label blitz_finish:
    python:
        global blitz, start_time
        renpy.hide(blitz.start_image)
        renpy.show(blitz.end_image)
        time_spent = datetime.now() - start_time
        stats = persistent.stats['blitz'].get(battle_type, {
            "runs": 0,
            "score": 0,
            "time": 0,
        })
        stats['runs'] += 1
        is_record = ""
        if blitz.correct > stats['score']:
            stats['score'] = blitz.correct
            stats['time'] = time_spent.seconds
            stats['max_score'] = blitz.max_count
            is_record = "Новый рекорд!"
        elif blitz.correct == stats['score'] and time_spent.seconds < stats['time']:
            stats['time'] = time_spent.seconds
            stats['max_score'] = blitz.max_count
            is_record = "Новый рекорд!"
        persistent.stats['blitz'][battle_type] = stats

    if blitz.correct == blitz.max_count:
        nuke "Поздравляю, [persistent.player_name]!"
    else:
        nuke "Поздравляю (или нет), [persistent.player_name]!"

    menu:
        "Твой результат: [blitz.correct]/[blitz.max_count] правильных ответов за [time_spent.seconds] сек.! [is_record]"
        "Еще раз!":
            python:
                global challenger
                if not challenger:
                    challenger = persistent.player_name
            jump blitz_start
        "Выход":
            $ exit_blitz()
            return
        "Бросить вызов чатерсам!":
            python:
                url = "https://alexfess.itch.io/rgg-land-rules-exam"
                if renpy.emscripten:
                    import emscripten
                    href = emscripten.run_script_string("window.location.href")
                    if "idev.games" in href:
                        url = "https://idev.games/game/rgg-land-rules-exam"
                    elif ".itch.io" not in href:
                        url = "https://alexfess.github.io/rgg-land-exam/"
#                     url = href.split('?')[0]
#                 else:
#                     url = "https://alexfess.itch.io/rgg-land-rules-exam"
#                 import urllib.parse
#                 c = urllib.parse.quote(persistent.player_name)
#                 b = battle_arch * 100 + battle_type * 10
#                 url = f"{url}?bc={b}&cn={c}"

                c_text = f"BASEDCIGAR {blitz.correct}/{blitz.max_count} в {blitz.names[battle_type]} РГГ-тесте за {time_spent.seconds} сек! Сможешь лучше? Вперёд! Chatting {url}"
                if renpy.emscripten:
                    emscripten.run_script(f"navigator.clipboard.writeText('{c_text}')")
                else:
                    import pygame as pg
                    import pygame.scrap as scrap
                    scrap.put(pg.SCRAP_TEXT, c_text.encode("utf-8"))
                renpy.say(None, "Вызов скопирован в буфер обмена. Бежим постить в чат!")
                exit_blitz()
            return

label answer_blitz:
    python:
        if is_blitz_correct:
            blitz.correct += 1
            renpy.notify("Истинно так!")
        else:
            renpy.notify("А вот и нет!")
        blitz.count += 1
        renpy.block_rollback()
        if blitz.count >= blitz.max_count:
            renpy.jump("blitz_finish")
        else:
            renpy.jump("blitz_next")


label blitz_text:
    python:
        is_blitz_correct = False
        current_ans = None
        qq = blitz.current_question.get('menu_options').copy()
        correct = qq[0]
        random.shuffle(qq)
    menu:
        nuke "([blitz.count+1] из [blitz.max_count]) [blitz.current_question.get('text')]"
        "[qq[0]]":
            $ current_ans = qq[0]
        "[qq[1]]":
            $ current_ans = qq[1]
        "[qq[2]]":
            $ current_ans = qq[2]
        "[qq[3]]":
            $ current_ans = qq[3]
    $ is_blitz_correct = current_ans == correct
    jump answer_blitz


# import random
# # from random import Random
#
# seed = random.randint(10000, 99999)
# rnd = random.Random(seed)
# # rnd.getstate()
#
# # print(rnd.getstate())
#
# print(rnd.randint(10000, 99999))
import os
import sys
import urllib.parse
from collections import namedtuple

# for p in str("url_search").split('?', 2)[-1].split('&', 2):
#     print(p)

# from datetime import datetime, timedelta
#
# d1 = datetime.now()
# d2 = datetime.now() - timedelta(minutes=1, seconds=6)
#
# dd = d1 - d2
# print(dd.seconds)

# d = namedtuple('f1', 'v1')
# dt = namedtuple('T', 'f1')
# d = dt('v0')
# d = object()
# d.f1 = 'v1'
# print(d.f1)
#
# sorted()

log_dir = "C:/Utils/ProxiFyre/logs"
log_file = f"{log_dir}/logfile_2025-06-27.txt"
# log_files = os.listdir(log_dir))

class Var:

    def __init__(self, **kwargs):
        self.__dict__ = self.__dict__ or {}
        for k, v in kwargs.items():
            self.__dict__[k] = v

image modal_bg:
        "#000"
        alpha 0.7

screen records():
    modal True
    zorder 2
    add "modal_bg"
    textbutton "Закрыть":
        yalign 0.05
        xalign 0.9
        action Hide("records")

    grid 3 4:
        xalign 0.5
        yalign 0.1
        spacing 50
        # Table header
#         hbox:
#             spacing 50
        text "Тип" bold True xalign 0.5
        text "Лучший результат" bold True xalign 0.5
        text "Кол-во попыток" bold True xalign 0.5

        $ recs = persistent.stats['blitz'].items()
        $ recs = sorted(recs, key=lambda x: x[0])
        $ batls = {1: 'Быстрый', 2: 'Полный', 3: 'Душный'}
        # Display records
        for i, record in enumerate(recs, 1):
            if record[1]["runs"] > 0:
#                 hbox:
#                     spacing 50
                text batls[record[0]] xalign 0.5
                text f'{record[1]["score"]}/{record[1].get("max_score", "?")} за {record[1]["time"]} сек.':
                    xalign 0.5
                text str(record[1]["runs"]) xalign 0.5
﻿# Вы можете расположить сценарий своей игры в этом файле.

# Определение персонажей игры.
define nuke = Character('Nuke73', color="#c8ffc8")
# define p1 = Character('Участник', color="#c8ffc8")

init:
    python:
        config.keymap['quick_save'] = []
        config.keymap['quick_load'] = []
        config.keymap['save'] = []
        config.keymap['load'] = []
        config.keymap['self_voicing'] = []
        config.webaudio_required_types = []


# Игра начинается здесь:
# label start:
#     scene
#
#     show map at topleft
#
#     menu:
#         nuke "Привет, знаток кодекса из чата :/ Проверим-ка насколько ты знаешь правила?"
#         "Начать экзамен":
#             jump start_exam
#
# label start_exam:
#     $ next_question()
#     jump quiz

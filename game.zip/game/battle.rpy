

label start_battle:
    scene
    show m32 at center
    jump start_battle_choice


label start_battle_choice:
    menu:
        "Готов к битве, [persistent.player_name]?"
        "Принять вызов от [challenger]":
            jump blitz_start
        "Да ну нах!":
            $ exit_blitz()
            return
        "Я не [persistent.player_name]!":
            call screen input_name()
            jump start_battle_choice


# Screen for inputting the user's name
screen input_name():
    modal True  # Prevents interaction with other screens
    zorder 2
    add "modal_bg"

    # Background for the input screen
    frame:
        xalign 0.5
        yalign 0.5
        xpadding 30
        ypadding 30

        vbox:
            spacing 10

            # Display the prompt
            text "Твой ник":
                xalign 0.5

            # Input field for the user's name
            input:
                id "name_input"
                default ""
                length 20  # Maximum length of the input
                xalign 0.5
                copypaste True
                value VariableInputValue("persistent.player_name")  # Bind input to the player_name variable

            # Button to confirm the input
            textbutton "Подтвердить":
                xalign 0.5
                action Return()  # Close the screen and return to the game
            key 'K_RETURN' action Return()
